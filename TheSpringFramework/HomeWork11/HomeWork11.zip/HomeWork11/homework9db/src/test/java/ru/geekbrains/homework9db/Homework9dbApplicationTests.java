package ru.geekbrains.homework9db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Homework9dbApplicationTests {

	@Test
	void contextLoads() {
	}

}
