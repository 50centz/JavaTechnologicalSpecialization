package ru.geekbrains.homework9db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Homework9dbApplication {

	public static void main(String[] args) {
		SpringApplication.run(Homework9dbApplication.class, args);
	}

}
